IP-XACT 2014 package
====================

Files
-----
- UART.component.xml: UART ports and a memory map with CTRL/STATUS registers.
- APB_BUS.component.xml: conservative wrapper for the two supplied APB-like signals.
- CPU.component.xml: CPU and IRQ port.
- circuit1.design.xml: component instances and supplied node-level topology.
- assumptions.json: every inferred value and the missing data needed for sign-off.

Important limitation
--------------------
The original JSON/XLSX does not define named bus interfaces, complete APB signals,
signal roles, endpoint port mappings, addresses, or register fields. Therefore,
the component descriptions use standard IP-XACT structures, while the three
component-to-component graph links are retained in a namespaced vendor extension.
Inventing standard interconnections without endpoint data would create a misleading
file that may be syntactically plausible but electrically incorrect.
