from pathlib import Path
import json
import sys
import xml.etree.ElementTree as ET

IPXACT = "http://www.accellera.org/XMLSchema/IPXACT/1685-2014"
APP = "urn:example:ipxact-json-mapping:1.0"
NS = {"ipxact": IPXACT, "app": APP}

def text(parent, path):
    node = parent.find(path, NS)
    if node is None or node.text is None:
        raise ValueError(f"Missing required value: {path}")
    return node.text.strip()

def parse_component(path):
    root = ET.parse(path).getroot()
    name = text(root, "ipxact:name")
    metadata = root.find("ipxact:vendorExtensions/app:jsonMetadata", NS)
    component_type = metadata.get("componentType") if metadata is not None else "Component"

    ports = [
        text(port, "ipxact:name")
        for port in root.findall("ipxact:model/ipxact:ports/ipxact:port", NS)
    ]

    registers = [
        text(register, "ipxact:name")
        for register in root.findall(".//ipxact:register", NS)
    ]

    return name, {
        "type": component_type,
        "ports": ports,
        "registers": registers
    }

def parse_connections(path):
    root = ET.parse(path).getroot()
    return [
        {
            "source": connection.get("source"),
            "target": connection.get("target")
        }
        for connection in root.findall(
            "ipxact:vendorExtensions/app:connections/app:connection",
            NS
        )
    ]

def parse_package(directory):
    directory = Path(directory)
    components = {}

    for path in sorted(directory.glob("*.component.xml")):
        name, component = parse_component(path)
        components[name] = component

    design_files = list(directory.glob("*.design.xml"))
    if len(design_files) != 1:
        raise ValueError("Expected exactly one design XML file")

    return {
        "components": components,
        "connections": parse_connections(design_files[0])
    }

if __name__ == "__main__":
    directory = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent
    print(json.dumps(parse_package(directory), indent=4))
