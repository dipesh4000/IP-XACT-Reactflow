The original generic parser does not produce the target JSON shape.

Use:
    python parse_ipxact_to_json.py > parsed.json

The parser reads:
- component type from app:jsonMetadata
- ports from ipxact:model/ipxact:ports
- registers from ipxact:memoryMaps
- connections from the design vendor extension

The output is verified to exactly match IP_XACT_JSON(1).json.
